plumed driver --plumed plumed-driver.dat --timestep 0.002 --trajectory-stride 100 --mf_dcd out.dcd
